export const addUser = userIndex => (
    {
      type: 'ADD_USER',
      payload: userIndex,
    }
  );


  const name = {
    fname: "",
    lname: ""
}

export const setNames = (state = name, action) => {
    console.log("I am in setnNames")
    console.log(action.payload);
    let myPayload = {...action.payload};
    console.log(myPayload.fname);  //logs out correctly
    switch (action.type) {
        case addUser:
            return { ...state, fname: myPayload.fname, lname: myPayload.lname }
        default:
            return state;
    }
}