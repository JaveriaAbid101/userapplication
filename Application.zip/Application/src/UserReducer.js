import { combineReducers } from 'redux';

const INITIAL_STATE = {
  users:[
      'firstname',
      'lastname',
      'phonenumber',
      'email',
      'address'
       
  ]
};
const userReducer = (state = INITIAL_STATE, action) => {
switch (action.type) {
   case 'ADD_USER':  
         const {
           users,   
         } = state;
         const addedUser = users.splice(action.payload, 1);
         users.push(addedUser);
         const newState = { users };
         return newState;
     default:
       return state
   }
 };

 export default combineReducers({
 users: userReducer,
});